def funcion_modulo2():
    print("Hola soy una funcion del modulo2")
